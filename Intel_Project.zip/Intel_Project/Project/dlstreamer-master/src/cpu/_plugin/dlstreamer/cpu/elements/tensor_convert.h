/*******************************************************************************
 * Copyright (C) 2022 Intel Corporation
 *
 * SPDX-License-Identifier: MIT
 ******************************************************************************/

#include "dlstreamer/transform.h"

extern "C" {

extern dlstreamer::ElementDesc tensor_convert;
}
