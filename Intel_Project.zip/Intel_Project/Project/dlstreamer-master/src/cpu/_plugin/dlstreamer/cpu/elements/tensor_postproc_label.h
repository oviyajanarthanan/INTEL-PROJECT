/*******************************************************************************
 * Copyright (C) 2022 Intel Corporation
 *
 * SPDX-License-Identifier: MIT
 ******************************************************************************/

#pragma once

#include "dlstreamer/transform.h"

extern "C" {

extern dlstreamer::ElementDesc tensor_postproc_label;
}
