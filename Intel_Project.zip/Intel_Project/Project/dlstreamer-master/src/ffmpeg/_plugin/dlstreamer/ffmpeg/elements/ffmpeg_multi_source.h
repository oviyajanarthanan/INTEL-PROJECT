/*******************************************************************************
 * Copyright (C) 2022 Intel Corporation
 *
 * SPDX-License-Identifier: MIT
 ******************************************************************************/

#include "dlstreamer/source.h"

extern "C" {
extern dlstreamer::ElementDesc ffmpeg_multi_source;
}
