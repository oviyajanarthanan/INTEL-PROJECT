/*******************************************************************************
 * Copyright (C) 2022 Intel Corporation
 *
 * SPDX-License-Identifier: MIT
 ******************************************************************************/

#pragma once

#include "dlstreamer/opencv/utils.h"
#include <opencv2/core/ocl.hpp>

namespace dlstreamer {} // namespace dlstreamer
